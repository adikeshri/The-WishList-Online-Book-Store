<?php
namespace SendGrid\Mail;

class TypeException extends \Exception
{

}